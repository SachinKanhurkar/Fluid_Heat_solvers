clear all;
lx=115*0.001;
ly=120*0.001;
nx=400; % grid points in x
ny=400;
dx=lx/nx;
dy=ly/ny;
p(1:nx,1:ny)=0;
pin=3000;
pout=0;


for(i=1:nx)
    p(i,1)=pin;
end

for (i=1:nx)
    p(i,ny)=pout;
end
for (k=1:7000)

         for (i=2:nx-1)
         for (j=2:ny-1)
        
           p(i,j)=((p(i-1,j)+p(i+1,j))/(dx*dx)+(p(i,j-1)+p(i,j+1))/(dy*dy))/((2/(dx*dx))+(2/(dy*dy)));
          
         end;
         end
    for (j=2:ny-1)
    p(1,j)=p(2,j);
    p(nx,j)=p(nx-1,j);
    end;
end

u_x(1:nx-1,1:ny-1)=0;

k=9.3*10^(-8); % k value
mu=0.005; % viscosty
e=0.95; % epsilon

for (i=1:nx-1);
    for (j=1:ny-1)
        u_x(i,j)=-(k/(e*mu))*(p(i+1,j)-p(i,j))/dx;
    end
end
u_y(1:nx-1,1:ny-1)=0;
for (i=1:nx-1);
    for (j=1:ny-1)
        u_y(i,j)=-(k/(e*mu))*(p(i,j+1)-p(i,j))/dy;
    end
end

u_resultant(1:nx-1,1:ny-1)=0;
for (i=1:nx-1);
    for (j=1:ny-1)
        u_resultant(i,j)=sqrt(u_x(i,j)*u_x(i,j)+u_y(i,j)*u_y(i,j));
    end
end
u_avg=0;
% to find Q out 
for (i=1:nx-1);
    
u_avg=u_avg+dx*u_y(i,ny-1)/lx;
end
Q=u_avg*lx; % flow rate in m^3/sec see a value in workspace in workspace 

% select the progrmae above this and right clik then "evalution selection"
    %***********************************************************************%

    
% run above progrmamme for every pout i.e.500 , 1000 , 1500 , 2000 ... then
% see Q in workspace for every Pout then put it in "presuusredrop_q.txt"
% Then run the below prgrmme which give the slope value in command window.
    
    
 B=dlmread('presuusredrop_q.txt');
 x=B(:,1);
 y=B(:,2);

 c = polyfit(x,y,1);
% Display evaluated equation y = m*x + b
disp(['Equation is y = ' num2str(c(1)) '*x + ' num2str(c(2))])
% Evaluate fit equation using polyval
y_est = polyval(c,x);
% Add trend line to plot
hold on
plot(x,y,'o',x,y_est,'LineWidth',1.5);
xlabel('Flow Rate (in m^3/sec)','FontSize',12);
ylabel('Pressure Drop [Pa]','FontSize',12);
hold off

    
    