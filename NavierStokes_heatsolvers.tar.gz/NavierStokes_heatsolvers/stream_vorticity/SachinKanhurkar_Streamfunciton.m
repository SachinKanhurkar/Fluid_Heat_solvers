dx=0.05;
dy=0.05;
Nx=20+1;
Ny=20+1;
r=1.7;Re=10;
dt=0.005;time=0.0;
si=zeros(Nx,Ny);si2=zeros(Nx,Ny);
x=zeros(Nx,Ny);y=zeros(Nx,Ny);
for i=1:Nx,
    for j=1:Ny,
        w(i,j)= 2*pi*pi*sin(pi*(i-1)*dx)*sin(pi*(j-1)*dy);
       % w(i,j)=0;
    end;
end;
for j=1:Ny,
    si(1,j)=0;
    si(Nx,j)=0;
end;
for i=1:Nx,
    si(i,1)=0;
    si(i,Ny)=0;
end;
for i=2:Nx-1,
    for j=2:Ny-1,
        si(i,j)=0;
    end;
end;
time=0.0;
for timestep=1:100,
   
    for n=1:700,
        for i=2:Nx-1,for j=2:Ny-1,
        si(i,j)=(0.25*(si(i+1,j)+si(i-1,j)+si(i,j+1)+si(i,j-1)+dx*dx*w(i,j)))*r+(1-r)*si(i,j);
       end; end;  
    for i=1:Nx,for j=1:Ny,
        si2(i,j)= sin(pi*(i-1)*dx)*sin(pi*(j-1)*dy);
    end;end;
   % for i=1:Nx,for j=1:Ny,
   % error= error+abs(si(i,j)-si2(i,j));
   % end;end;
    end;
          
time=time+dt; 
           end;

          
        