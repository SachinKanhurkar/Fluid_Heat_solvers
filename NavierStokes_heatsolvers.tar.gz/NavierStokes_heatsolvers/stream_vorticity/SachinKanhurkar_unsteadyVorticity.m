dx=0.05;
dy=0.05;
imax=20+1;
jmax=20+1;
r=1.7;Re=10;
dt=0.005;time=0.0;
si=zeros(imax,jmax);si2=zeros(imax,jmax);w=zeros(imax,jmax);w_new=zeros(imax,jmax);
x=zeros(imax,jmax);y=zeros(imax,jmax);
for i=1:imax,
    for j=1:jmax,
        w(i,j)= 2*pi*pi*sin(pi*(i-1)*dx)*sin(pi*(j-1)*dy);
       % w(i,j)=0;
    end;
end;
for j=1:jmax,
    si(1,j)=0;
    si(imax,j)=0;
end;
for i=1:imax,
    si(i,1)=0;
    si(i,jmax)=0;
end;
for i=2:imax-1,
    for j=2:jmax-1,
        si(i,j)=0;
    end;
end;
time=0.0;
for timestep=1:100,
    w=w_new;
  
    for n=1:700,
        for i=2:imax-1,for j=2:jmax-1,
        si(i,j)=(0.25*(si(i+1,j)+si(i-1,j)+si(i,j+1)+si(i,j-1)+dx*dx*w(i,j)))*r+(1-r)*si(i,j);
       end; end;  
    for i=1:imax,for j=1:jmax,
        si2(i,j)= sin(pi*(i-1)*dx)*sin(pi*(j-1)*dy);
    end;end;
   % for i=1:imax,for j=1:jmax,
   % error= error+abs(si(i,j)-si2(i,j));
   % end;end;
    end;
    
           w(2:imax-1,1)=-2.0*si(2:imax-1,2)/(dx*dx); %bottom wall
           w(1,2:jmax-1)=-2.0*si(2,2:jmax-1)/(dx*dx);  % left wall
           w(imax,2:jmax-1)=-2.0*si(imax-1,2:jmax-1)/(dx*dx);% right wall
           
          for(i=2:imax-1)
             w(i,jmax)=-2.0*si(i,jmax)/(dx*dx)+(2/dx)*sin(pi*(i-1)*dx)*sin(pi*(i-1)*dx);% top wall
          end;
          
   
     for (i=2:imax-1);for (j=2:jmax-1)
       w_new(i,j)=w(i,j)+dt*(-0.25*((si(j-1,i)-si(i,j+1))*(w(i+1,j)-w(i-1,j))+(si(i+1,j)-si(i-1,j))*(w(i,j+1)-w(i,j-1))))+dt/(Re*dx*dx)*(w(i+1,j)+w(i-1,j)+w(i,j+1)+w(i,j-1)-4*w(i,j));
     end;end; 
time=time+dt; 
           end;

          subplot (121) , contour (w_new,40), axis ('square'); 
          
          subplot (122) , contour (si,40), axis ('square'); 
        