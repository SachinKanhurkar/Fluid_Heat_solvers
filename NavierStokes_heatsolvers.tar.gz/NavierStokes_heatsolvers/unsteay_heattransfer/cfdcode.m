% Flux based methodology of CFD devolement and code verification for 1D
% unstady state heat conduction problem%

%step1- Input
rho=7750;
cp=500;
k=16.2;
l=1;
imax=12;
to=30;
twb=0;
teb=100;
Qvolgen=0;
epsilon_st=0.0001;
%Step2- Geometric parameters and stability criteria
alpha=k/(rho*cp);
DTc=teb-twb;
Dx=l/(imax-2);
Dt=0.99*0.5*(Dx*Dx/alpha);
Qgen=Qvolgen*Dx; %total heat generation
%step3- Initial condition and BC
%T=zeros(imax);

T(2:imax-1)=to;

T(1)=twb;
T(imax)=teb;
%qx_old(1:imax)=1;
%Q_cond_old(1:imax)=1;
%time marching for explicite method
unsteadyness_nd=1;n=0;

while unsteadyness_nd>=epsilon_st
    n=n+1;
    T_old=T;
    %computation of condution heat flux
    for i=1:imax-1
        if(i==1)||(i==imax-1) 
            qx_old(i)=-k*(T_old(i+1)-T_old(i))/(Dx/2);
        else
            qx_old(i)=-k*(T_old(i+1)-T_old(i))/(Dx);
        end
    end
        for i=2:imax-1
            Q_cond_old(i)=(qx_old(i-1)-qx_old(i));
            T(i)=T_old(i)+(Dt/(rho*cp*Dx))*(Q_cond_old(i)+Qgen);
        end
        %steady state convergence
        unsteadyness=max(abs(T-T_old))/Dt;
        unsteadyness_nd=unsteadyness*l*l/(alpha*DTc);
 
        %while loop end
end
%display(T)