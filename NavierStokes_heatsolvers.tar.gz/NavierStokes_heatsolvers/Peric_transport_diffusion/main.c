#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <fstream>

#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))
#define MAX(X,Y) ((X) > (Y) ? (X) : (Y))
#define ma2d(I,J,nj) ((I)*(nj+2)+(J))

typedef struct _State State;
struct _State {
  double lx, ly; // size of domain
  int nx, ny; // number of points on Cartesian grid
  double *p;
  double *x,*xc;
 // double u;
//  double mx;
  double *y,*yc;
 // double v;
 // double my;
  double *dx , *dy;
  double *dxc , *dyc ;
  double *fi;
  };
  State state1, *state ;

using namespace std;

int main(int argc, char *argv[]) {
state=&state1;
state->lx=1.0;
state->ly=1.0;
state->nx=100;
state->ny=100;
int i , j;

state->x=(double*) malloc(sizeof(double)*(state->nx+1));
state->xc=(double*) malloc(sizeof(double)*(state->nx+2));
state->y=(double*) malloc(sizeof(double)*(state->ny+1));
state->yc=(double*) malloc(sizeof(double)*(state->ny+2));
state->dx=(double*) malloc(sizeof(double)*(state->nx));
state->dy=(double*) malloc(sizeof(double)*(state->ny));
state->fi=(double*) malloc(sizeof(double)*(state->nx+2)*(state->ny+2));


double u[state->nx+1][state->ny];
double v[state->nx][state->ny+1];
double mx[state->nx+1][state->ny];
double my[state->nx][state->ny+1];
/****************************Discrtization*********************************************/
for (i=0;i<=state->nx-1;i++)
	{
	state->dx[i]=state->lx/state->nx;
	}
state->x[0]=0.0;
for (i=1;i <= state->nx;i++)
	{
	state->x[i]=state->x[i-1]+state->dx[i-1];
	}
for (j=0;j<=state->ny-1;j++)
	{
	state->dy[j]=state->ly/state->ny;
	}
state->y[0]=0.0;
for (j=1;j <= state->ny;j++)
	{
	state->y[j]=state->y[j-1]+state->dy[j-1];
	}

state->xc[0]=state->x[0];
state->xc[state->nx+1]=state->x[state->nx];
for (i=1;i<=state->nx;i++)
	{
	state->xc[i]=0.5*(state->x[i]+state->x[i-1]);
	}
	
state->yc[0]=state->y[0];
state->yc[state->ny+1]=state->y[state->ny];
for (i=1;i<=state->ny;i++)
	{
	state->yc[i]=0.5*(state->y[i]+state->y[i-1]);
	}

for (i=0;i<=state->ny+1;i++)
	{
	printf("yc  %d =  %12.8f \n  ",i, state->yc[i]);
	}
printf("\n ");

for (i=0;i<=state->nx+1;i++)
	{
	printf("xc  %d =  %12.8f \n  ",i, state->xc[i]);
	}
	
for (i=0;i<=state->ny;i++)
	{
	printf("y  %d =  %12.8f \n  ",i, state->y[i]);
	}
printf("\n ");

for (i=0;i<=state->nx;i++)
	{
	printf("x  %d =  %12.8f \n  ",i, state->x[i]);
	}	
	
		
/******************************************************************************/
double tau=0.010;
double rho=1.0;
for (i=0;i<=state->nx;i++)
	{for (j=0;j<=state->ny-1;j++)
	{
	u[i][j]=state->x[i];
	printf("u %d  %d  = %12.6f \n ",i, j , u[i][j]);
	mx[i][j]=rho*u[i][j]*(state->y[j+1]-state->y[j]);
	printf("mx %d  %d  = %12.6f \n ",i, j , mx[i][j]);
	}
	}
	
for (i=0;i<=state->nx-1;i++)
	{for (j=0;j<=state->ny;j++)
	{
	v[i][j]=-state->y[j];
	printf("v %d  %d  = %12.6f \n ",i, j , v[i][j]);
	my[i][j]=rho*v[i][j]*(state->x[i+1]-state->x[i]);
	printf("my %d  %d  = %12.6f \n ",i, j , my[i][j]);
	}
	}
/************************************************************************************/
double AWC[(state->nx+2)*(state->ny+2)];
double AEC[(state->nx+2)*(state->ny+2)];
double APC[(state->nx+2)*(state->ny+2)];
double ANC[(state->nx+2)*(state->ny+2)];
double ASC[(state->nx+2)*(state->ny+2)];
for (i=0;i<=state->nx+1;i++)
	{for (j=0;j<=state->ny+1;j++)
	{
		AEC[ma2d(i+1,j,state->ny)]=0;
		AWC[ma2d(i-1,j,state->ny)]=0;
		ANC[ma2d(i,j+1,state->ny)]=0;
		ASC[ma2d(i,j-1,state->ny)]=0;
		APC[ma2d(i,j,state->ny)]=0;
	}
	}


for (i=1;i<=state->nx;i++)
	{for (j=1;j<=state->ny;j++)
	{
		AEC[ma2d(i+1,j,state->ny)]=MIN(mx[i][j-1],0);
		AWC[ma2d(i-1,j,state->ny)]=MIN(mx[i-1][j-1],0);
		ANC[ma2d(i,j+1,state->ny)]=MIN(my[i-1][j],0);
		ASC[ma2d(i,j-1,state->ny)]=MIN(my[i-1][j-1],0);
		APC[ma2d(i,j,state->ny)]=-(AEC[ma2d(i+1,j,state->ny)]+AWC[ma2d(i-1,j,state->ny)]+ANC[ma2d(i,j+1,state->ny)]+ASC[ma2d(i,j-1,state->ny)]);
	}
	}
	
/*	printf("\n ");
	for (i=0;i<=state->nx+1;i++){
	for (j=0;j<=state->ny+1;j++)
        {
	printf("Aec %d %d  =  %12.8f  \n  ",i , j ,AEC[ma2d(i,j,state->ny)]);
	printf("Awc %d %d  =  %12.8f  \n  ",i , j ,AWC[ma2d(i,j,state->ny)]);
	printf("Anc %d %d  =  %12.8f  \n  ",i , j ,ANC[ma2d(i,j,state->ny)]);
	printf("Asc %d %d  =  %12.8f  \n  ",i , j ,ASC[ma2d(i,j,state->ny)]);
	printf("Apc %d %d  =  %12.8f  \n  ",i , j ,APC[ma2d(i,j,state->ny)]);
	}
	printf("\n ");
	}
*/	
        printf("\n ");
	printf("Aec %d %d  =  %12.8f  \n  ",5 , 4 ,AEC[ma2d(5,4,state->ny)]);
	printf("Awc %d %d  =  %12.8f  \n  ",3 , 4 ,AWC[ma2d(4,3,state->ny)]);
	printf("Anc %d %d  =  %12.8f  \n  ",4 , 5 ,ANC[ma2d(4,5,state->ny)]);
	printf("Asc %d %d  =  %12.8f  \n  ",4 , 3 ,ASC[ma2d(4,3,state->ny)]);
	printf("Apc %d %d  =  %12.8f  \n  ",4 , 4 ,APC[ma2d(4,4,state->ny)]);
	
/************************************************************************************/
double AWD[(state->nx+2)*(state->ny+2)];
double AED[(state->nx+2)*(state->ny+2)];
double APD[(state->nx+2)*(state->ny+2)];
double AND[(state->nx+2)*(state->ny+2)];
double ASD[(state->nx+2)*(state->ny+2)];
for (i=0;i<=state->nx+1;i++)
	{for (j=0;j<=state->ny+1;j++)
	{
		AED[ma2d(i+1,j,state->ny)]=0;
		AWD[ma2d(i-1,j,state->ny)]=0;
		AND[ma2d(i,j+1,state->ny)]=0;
		ASD[ma2d(i,j-1,state->ny)]=0;
		APD[ma2d(i,j,state->ny)]=0;
	}
	}

for (i=1;i<=state->nx;i++)
	{for (j=1;j<=state->ny;j++)
	{
		AED[ma2d(i+1,j,state->ny)]=-tau*(state->y[j]-state->y[j-1])/(state->xc[i+1]-state->xc[i]);
		AWD[ma2d(i-1,j,state->ny)]=-tau*(state->y[j]-state->y[j-1])/(state->xc[i]-state->xc[i-1]);
		AND[ma2d(i,j+1,state->ny)]=-tau*(state->x[i]-state->x[i-1])/(state->yc[j+1]-state->yc[j]);
		ASD[ma2d(i,j-1,state->ny)]=-tau*(state->x[i]-state->x[i-1])/(state->yc[j]-state->yc[j-1]);
		APD[ma2d(i,j,state->ny)]=-(AED[ma2d(i+1,j,state->ny)]+AWD[ma2d(i-1,j,state->ny)]+AND[ma2d(i,j+1,state->ny)]+ASD[ma2d(i,j-1,state->ny)]);
	}
	}
	
	/*
	printf("\n ");
	for (i=0;i<=state->nx+1;i++){
	for (j=0;j<=state->ny+1;j++)
        {
	printf("Aed %d %d  =  %12.8f  \n  ",i , j ,AED[ma2d(i,j,state->ny)]);
	printf("Awd %d %d  =  %12.8f  \n  ",i , j ,AWD[ma2d(i,j,state->ny)]);
	printf("And %d %d  =  %12.8f  \n  ",i , j ,AND[ma2d(i,j,state->ny)]);
	printf("Asd %d %d  =  %12.8f  \n  ",i , j ,ASD[ma2d(i,j,state->ny)]);
	printf("Apd %d %d  =  %12.8f  \n  ",i , j ,APD[ma2d(i,j,state->ny)]);
	}
	printf("\n ");
	}
	
	*/
	
	printf("\n ");
	printf("Aed %d %d  =  %12.8f  \n  ",5 , 4 ,AED[ma2d(5,4,state->ny)]);
	printf("Awd %d %d  =  %12.8f  \n  ",3, 4 ,AWD[ma2d(4,3,state->ny)]);
	printf("And %d %d  =  %12.8f  \n  ",4 , 5 ,AND[ma2d(4,5,state->ny)]);
	printf("Asd %d %d  =  %12.8f  \n  ",4 , 3 ,ASD[ma2d(4,3,state->ny)]);
	printf("Apd %d %d  =  %12.8f  \n  ",4 , 4 ,APD[ma2d(4,4,state->ny)]);
	

/******************************************************************************************/
double AE[(state->nx+2)*(state->ny+2)];
double AW[(state->nx+2)*(state->ny+2)];
double AP[(state->nx+2)*(state->ny+2)];
double AN[(state->nx+2)*(state->ny+2)];
double AS[(state->nx+2)*(state->ny+2)];
for (i=0;i<=state->nx+1;i++)
	{for (j=0;j<=state->ny+1;j++)
	{
		AE[ma2d(i+1,j,state->ny)]=0;
		AW[ma2d(i-1,j,state->ny)]=0;
		AN[ma2d(i,j+1,state->ny)]=0;
		AS[ma2d(i,j-1,state->ny)]=0;
		AP[ma2d(i,j,state->ny)]=0;
	}
	}

for (i=1;i<=state->nx;i++)
	{for (j=1;j<=state->ny;j++)
	{
		AE[ma2d(i+1,j,state->ny)]=AEC[ma2d(i+1,j,state->ny)]+AED[ma2d(i+1,j,state->ny)];
		AW[ma2d(i-1,j,state->ny)]=AWC[ma2d(i-1,j,state->ny)]+AWD[ma2d(i-1,j,state->ny)];
		AN[ma2d(i,j+1,state->ny)]=ANC[ma2d(i,j+1,state->ny)]+AND[ma2d(i,j+1,state->ny)];
		AS[ma2d(i,j-1,state->ny)]=ASC[ma2d(i,j-1,state->ny)]+ASD[ma2d(i,j-1,state->ny)];
		AP[ma2d(i,j,state->ny)]=-(AE[ma2d(i+1,j,state->ny)]+AW[ma2d(i-1,j,state->ny)]+AN[ma2d(i,j+1,state->ny)]+ AS[ma2d(i,j-1,state->ny)]);
		//AP[ma2d(i,j,state->ny)]=APC[ma2d(i,j,state->ny)]+APD[ma2d(i,j,state->ny)];
		printf("Ap %d %d  =  %12.8f  \n  ",i , j ,AP[ma2d(i,j,state->ny)]);
	}
	}
/*	
	printf("\n ");
	for (i=0;i<=state->nx+1;i++){
	for (j=0;j<=state->ny+1;j++)
        {
	printf("Ae %d %d  =  %12.8f  \n  ",i , j ,AE[ma2d(i,j,state->ny)]);
	printf("Aw %d %d  =  %12.8f  \n  ",i , j ,AW[ma2d(i,j,state->ny)]);
	printf("An %d %d  =  %12.8f  \n  ",i , j ,AN[ma2d(i,j,state->ny)]);
	printf("As %d %d  =  %12.8f  \n  ",i , j ,AS[ma2d(i,j,state->ny)]);
	printf("Ap %d %d  =  %12.8f  \n  ",i , j ,AP[ma2d(i,j,state->ny)]);
	}
	printf("\n ");
	}
	
*/	
 printf("\n ");
	printf("Ae %d %d  =  %12.8f  \n  ",5 , 1 ,AE[ma2d(5,1,state->ny)]);
	printf("Aw %d %d  =  %12.8f  \n  ",3 , 1 ,AW[ma2d(3,1,state->ny)]);
	printf("An %d %d  =  %12.8f  \n  ",4 , 2 ,AN[ma2d(4,2,state->ny)]);
	printf("As %d %d  =  %12.8f  \n  ",4 , 0 ,AS[ma2d(4,0,state->ny)]);
	printf("Ap %d %d  =  %12.8f  \n  ",4 , 1 ,AP[ma2d(4,1,state->ny)]);
	
	printf("Aw %d %d  =  %12.8f  \n  ",4 , 2 ,AW[ma2d(4,2,state->ny)]);
	
	printf("Aw %d %d  =  %12.8f  \n  ",3 ,2 ,AW[ma2d(3,2,state->ny)]);
	
	printf("Aw %d %d  =  %12.8f  \n  ",2 ,2 ,AW[ma2d(2,2,state->ny)]);
	printf("Aw %d %d  =  %12.8f  \n  ",1 ,3 ,AW[ma2d(1,3,state->ny)]);
	
/************************************************************************************************/
for (i=0;i<=state->nx+1;i++)
	{for (j=0;j<=state->ny+1;j++)
	{
	state->fi[ma2d(i,j,state->ny)]=0.0;
	//state->fi[ma2d(0,j,state->ny)]=1.0-(state->yc[j]-state->yc[0])/(state->yc[state->ny+1]-state->yc[0]);
	 state->fi[ma2d(0,j,state->ny)]=(1.0-0.0)*(state->yc[state->ny+1]-state->yc[j])/(state->yc[state->ny+1]-state->yc[0]);
	//state->fi[ma2d(0,j,state->ny)]=(1.0-0.0)*(1.0-state->yc[j])/(1.0-0);
	}
	}
		
	
double Qp[(state->nx+2)*(state->ny+2)];
for (i=0;i<=state->nx+1;i++)
	{for (j=0;j<=state->ny+1;j++)
	{
	Qp[ma2d(i,j,state->ny)]=0.0;
	}
	}
/*********************Bc*************************/	
	     
	     
	 printf("\n ");
	for (i=1;i<=state->nx;i++){
	for (j=1;j<=state->ny;j++)
        {
	printf("Ap %d %d  =  %12.8f  \n  ",i, j, AP[ma2d(i,j,state->ny)]);
	}
	printf("\n ");
	} 
	
	
	printf(" BC STARTED\n ");
     
     ////WEST BOUNDARY - DIRICHLET B.C. 
      
      for (j=1;j<=state->ny;j++)
      {
      Qp[ma2d(1,j,state->ny)]=Qp[ma2d(1,j,state->ny)]-AW[ma2d(0,j,state->ny)]*state->fi[ma2d(0,j,state->ny)];
      printf("Qp %d %d  =  %12.8f  \n  ",1,j,Qp[ma2d(1,j,state->ny)]);
      AW[ma2d(0,j,state->ny)]=0;
      }
   
           
	 printf("bellow west bc \n ");
	for (i=1;i<=state->nx;i++){
	for (j=1;j<=state->ny;j++)
        {
	printf("Ap %d %d  =  %12.8f  \n  ",i, j, AP[ma2d(i,j,state->ny)]);
	}
	printf("\n ");
	} 
     
     
     ///EAST BOUNDARY - OTFLOW B.C. (ZERO-GRAD. EXTRAPOLATION)
      for (j=1;j<=state->ny;j++)
      {
       AP[ma2d(state->nx,j,state->ny)]=AP[ma2d(state->nx,j,state->ny)]+AE[ma2d(state->nx+1,j,state->ny)];
       printf("AP %d %d  =  %12.8f  \n  ",state->nx,j,AP[ma2d(state->nx,j,state->ny)]);
       
       AE[ma2d(state->nx+1,j,state->ny)]=0;
      }         
       
      
      
         printf("AP(east boundary) %d %d  =  %12.8f  \n  ",4,1,AP[ma2d(4,1,state->ny)]);
         printf("AE(east boundary) %d %d  =  %12.8f  \n  ",5,1,AS[ma2d(5,1,state->ny)]);
      
        printf("bellow east  bc \n ");
	for (i=1;i<=state->nx;i++){
	for (j=1;j<=state->ny;j++)
        {
	printf("Ap %d %d  =  %12.8f  \n  ",i, j, AP[ma2d(i,j,state->ny)]);
	}
	printf("\n ");
	} 
     
        
    
     // NORTH BOUNDARY - INLET B.C.
      for (i=1;i<=state->nx;i++)
      {
       Qp[ma2d(i,state->ny,state->ny)]=Qp[ma2d(i,state->ny,state->ny)]-AN[ma2d(i,state->ny+1,state->ny)]*state->fi[ma2d(i,state->ny+1,state->ny)];
       printf("QP %d %d  =  %12.8f  \n  ",i,state->ny,Qp[ma2d(i,state->ny,state->ny)]);
       
       AN[ma2d(i,state->ny+1,state->ny)]=0;
      }
      
     /// SOUTH BOUNDARY - SYMMETRY B.C.
     printf("AP(south boundary) %d %d  =  %12.8f  \n  ",2,1,AS[ma2d(2,1,state->ny)]);
     printf("AP(south boundary) %d %d  =  %12.8f  \n  ",4,1,AS[ma2d(4,1,state->ny)]);
     
     printf("As(south boundary) %d %d  =  %12.8f  \n  ",2,0,AS[ma2d(2,0,state->ny)]);
     printf("As(south boundary) %d %d  =  %12.8f  \n  ",4,0,AS[ma2d(4,0,state->ny)]);
     for (i=1;i<=state->nx;i++)
      {

       AP[ma2d(i,1,state->ny)]=AP[ma2d(i,1,state->ny)]+AS[ma2d(i,0,state->ny)];

       printf("AP(south boundary) %d %d  =  %12.8f  \n  ",i,1,AP[ma2d(i,1,state->ny)]);
       AS[ma2d(i,0,state->ny)]=0;
       printf("\n ");
      }
      
      //corner point
    //  Qp[ma2d(state->nx,1,state->ny)]=Qp[ma2d(state->nx,1,state->ny)]-AE[ma2d(state->nx+1,1,state->ny)]*state->fi[ma2d(state->nx+1,1,state->ny)]-AS[ma2d(state->nx,0,state->ny)]*state->fi[ma2d(state->nx,0,state->ny)];
     AP[ma2d(state->nx,1,state->ny)]=AP[ma2d(state->nx,1,state->ny)]+AE[ma2d(state->nx+1,1,state->ny)]+AS[ma2d(state->nx,0,state->ny)];
       AE[ma2d(state->nx+1,1,state->ny)]=0;
       AS[ma2d(state->nx,0,state->ny)]=0;
    
     
      Qp[ma2d(state->nx,state->ny,state->ny)]=Qp[ma2d(state->nx,state->ny,state->ny)]-AN[ma2d(state->nx,state->ny+1,state->ny)]*state->fi[ma2d(state->nx,state->ny+1,state->ny)];
     AP[ma2d(state->nx,state->ny,state->ny)]=AP[ma2d(state->nx,state->ny,state->ny)]+AE[ma2d(state->nx+1,state->ny,state->ny)];
     AE[ma2d(state->nx+1,state->ny,state->ny)]=0;
     AN[ma2d(state->nx,state->ny+1,state->ny)]=0;

	
	Qp[ma2d(1,1,state->ny)]=Qp[ma2d(1,1,state->ny)]-AW[ma2d(0,1,state->ny)]*state->fi[ma2d(0,1,state->ny)];
	AP[ma2d(1,1,state->ny)]=AP[ma2d(1,1,state->ny)]+AS[ma2d(1,0,state->ny)];
	AW[ma2d(0,1,state->ny)]=0;
	AS[ma2d(1,0,state->ny)]=0;
	
	
	
	Qp[ma2d(1,state->ny,state->ny)]=Qp[ma2d(1,state->ny,state->ny)]-AW[ma2d(0,state->ny,state->ny)]*state->fi[ma2d(0,state->ny,state->ny)]-AN[ma2d(1,state->ny+1,state->ny)]*state->fi[ma2d(1,state->ny+1,state->ny)];
	// AP[ma2d(1,state->ny,state->ny)]=AP[ma2d(1,state->ny,state->ny)]+AW[ma2d(0,state->ny,state->ny)]+AN[ma2d(1,state->ny+1,state->ny)];
	 AW[ma2d(0,state->ny,state->ny)]=0;
	 AN[ma2d(1,state->ny+1,state->ny)]=0;
	 
      
/*
for (i=1;i<=state->nx;i++)
	{for (j=1;j<=state->ny;j++)
	{
	state->fi[ma2d(i-1,j,state->ny)]*A[ma2d(i-1,j,state->ny)]+state->fi[ma2d(i,j-1,state->ny)]*A[ma2d(i,j-1,state->ny)]+state->fi[ma2d(i,j,state->ny)]*A[ma2d(i,j,state->ny)]+state->fi[ma2d(i,j+1,state->ny)]*A[ma2d(i,j+1,state->ny)]+state->fi[ma2d(i+1,j,state->ny)]*A[ma2d(i+1,j,state->ny)]=Qp[ma2d(i,j,state->ny)];
	}
	}

*/
double beta = 1.2;

for (int k=1;k<=10000;k++)
{
printf("ITERATION  =  %d  \n ",k);

for (i=1;i<=state->nx;i++)
	{for (j=1;j<=state->ny;j++)
	{
 	state->fi[ma2d(i,j,state->ny)]=(-1.0/(AP[ma2d(i,j,state->ny)]))*(state->fi[ma2d(i-1,j,state->ny)]*AW[ma2d(i-1,j,state->ny)]+state->fi[ma2d(i,j-1,state->ny)]*AS[ma2d(i,j-1,state->ny)]+state->fi[ma2d(i,j+1,state->ny)]*AN[ma2d(i,j+1,state->ny)]+state->fi[ma2d(i+1,j,state->ny)]*AE[ma2d(i+1,j,state->ny)]-Qp[ma2d(i,j,state->ny)]);
 	printf("fi %d %d =  %12.8f \n ",i,j , state->fi[ma2d(i,j,state->ny)] );
	}
	}
	
	for (j=0;j<=state->ny+1;j++)
  {
 state->fi[ma2d(state->nx+1,j,state->ny)]= state->fi[ma2d(state->nx,j,state->ny)] ; 
  }
  
  for (i=0;i<=state->nx+1;i++)
  {
  state->fi[ma2d(i,0,state->ny)]= state->fi[ma2d(i,1,state->ny)] ; 
  }
   
}

 ofstream out1;
 out1.open("fi.txt"); 
 for (j=0;j<=state->ny+1;j++)
 {for (i=0;i<=state->nx+1;i++)
 {
 out1<<state->fi[ma2d(i,j,state->ny)]<< endl;
  }
  out1<<endl;
  }

/*
 for (j=0;j<=state->ny+1;j++)
 {for (i=0;i<=state->nx+1;i++)
 {
 out1<<state->fi[ma2d(i,j,state->ny)]<< " / ";
  }
  out1<<endl;
*/


return 0; 
}
